//!wrt
w96.sys.log.log("PowerUser96 Boot Started","PowerUser96","info")
w96.sys.execCmd("explorer")