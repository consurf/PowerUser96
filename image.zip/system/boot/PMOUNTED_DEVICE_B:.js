w96.FS.umount(B:)
w96.evt.sys.on('init-complete',async ()=>{let ifs = await new w96.fstype.LocalStorageFileSystem('B:'); ifs.volumeLabel = 'DVD'; await w96.FS.mount(ifs);})