w96.WRT.runFile("c:/system/boot/repo-mount.js");
