alert("Border is installed! Complete the configuration to get ready to use it!");
w96.sys.execCmd("border");