Windows 96 Aero Icon Theme
-----------------------------
Majority of icons are (C) Microsoft Corp.

Around 1/4 of the icons are modified Windows 7 icons to fit the specific needs of Windows 96.
Windows icons (C) Microsoft Corporation.
Modified icons (C) Plopilpy.