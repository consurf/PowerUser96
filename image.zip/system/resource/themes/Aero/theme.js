// Set vars
w96.ui.Theme.uiVars.maxWindowSizeFormulaW = "calc(100vw - -2px)";
w96.ui.Theme.uiVars.maxWindowSizeFormulaH = "calc(100vh - 44px)";
w96.ui.Theme.uiVars.superbarEnabled = true;

// Add start menubar
let username = 'User';
let sam = await w96.sys.sam.readSAM();
if(sam && sam.name) username = sam.name;

const startMenuItems = [
    {
        name: username,
        action: ()=>void w96.sys.execCmd("explorer", ["c:/user"])
    },
    {
        name: "Documents",
        action: ()=>void w96.sys.execCmd("explorer", ["c:/user/documents"])
    },
    {
        name: "App Data",
        action: ()=>void w96.sys.execCmd("explorer", ["c:/user/appdata"])
    },
    {
        name: "Trash",
        action: ()=>void w96.sys.execCmd("explorer", ["c:/trash"])
    },
    {
        type: "separator"
    },
    {
        name: "Computer",
        action: ()=>void w96.sys.execCmd("explorer", [])
    },
    {
        name: "Root",
        action: ()=>void w96.sys.execCmd("explorer", ["w:/"])
    },
    {
        type: "separator"
    },
    {
        name: "Run",
        action: ()=>void w96.sys.execCmd("run", [])
    },
    {
        name: "Control Panel",
        action: ()=>void w96.sys.execCmd("ctrl", [])
    },
    {
        name: "Help",
        action: ()=>void w96.sys.execCmd("wiki96", [])
    },
    {
        name: "Reboot",
        action: ()=>void w96.sys.execCmd("reboot", [])
    }
];

const quickProgramsMenuItems = [
    {
        name: "Explorer",
        icon: await w96.ui.Theme.getIconUrl("apps/explorer"),
        action: ()=>void w96.sys.execCmd("explorer", [])
    },
    {
        name: "Package Manager",
        icon: await w96.ui.Theme.getIconUrl("apps/pkmgr"),
        action: ()=>void w96.sys.execCmd("pkmgr", [])
    },
    {
        name: "Textpad",
        icon: await w96.ui.Theme.getIconUrl("apps/textpad"),
        action: ()=>void w96.sys.execCmd("textpad", [])
    }
];

let currentView = "quick";

function createListItem(label, icon, action) {
    const btn = document.createElement('div');
    btn.classList.add('item');

    btn.addEventListener('click', async (e)=>{
        let evtObj = {
            evt: e,
            cancel: false
        };

        await action(evtObj);

        if(!evtObj.cancel) {
            console.log("aero debug: close start");
            w96.evt.shell.emit('start-close');
        }
    });

    const iconEl = document.createElement('div');
    iconEl.className = "icon";
    iconEl.style.backgroundImage = `url(${icon})`;
    btn.appendChild(iconEl);

    const textEl = document.createElement('div');
    textEl.className = "text";
    textEl.innerText = label;
    btn.appendChild(textEl);

    return btn;
}

async function populateP1View(start, type, args) {
    currentView = type;
    const p1items = start.querySelector(".p1>.items");

    while(p1items.firstChild)
        p1items.removeChild(p1items.firstChild);

    //p1items.querySelectorAll("*").forEach((v)=>v.remove());

    if(type == "quick") {
        for(let i of quickProgramsMenuItems) {
            if(i.type == "separator") {
                const s = document.createElement('div');
                s.classList.add('separator');
                p1items.appendChild(s);
            } else {
                p1items.appendChild(createListItem(i.name, i.icon, i.action));
            }
        }
    } else if(type == "programs") {
        const diskContents = await w96.FS.readdir((args == null) ? "c:/system/programs" : args);
        const cleanNames = diskContents.map((v)=>w96.FSUtil.fname(v));
        if(args && (args != "c:/system/programs") && (args !== "C:/system/programs")) {
            let upEl = createListItem("..", await w96.ui.Theme.getIconUrl("places/folder", "16x16"), async (e)=>{
                e.cancel = true;
                populateP1View(start, "programs", w96.FSUtil.getParentPath(args));
                e.evt.stopPropagation();
            });

            upEl.classList.add('small');
            p1items.appendChild(upEl);
        }

        cleanNames.aForEach(async(n, i)=>{
            let el = createListItem(n, await w96.ui.Theme.getFileIconUrl(diskContents[i], "16x16"), async (e)=>{
                if(await w96.FS.isFile(diskContents[i])) {
                    w96.sys.execFile(diskContents[i]);
                } else {
                    e.evt.stopPropagation();
                    e.cancel = true;

                    // Open and close directory.
                    populateP1View(start, "programs", diskContents[i]);
                }
            });

            el.classList.add('small');
            p1items.appendChild(el);
        });
    }
}

let fnStartOpen = async (e)=>{
    e.remove();
    // Replace start menu
    const start = document.createElement('div');
    start.className = "start-menu oc-event-exempt";

    start.innerHTML = `
        <div class="account">
            <div class="account-pfp"></div>
            <span>User</span>
        </div>
        <div class="huge-ahh-line"></div>
        <div class="container">
            <div class="p1">
                <div class="items"></div>
                <div class="all-programs">
                    <hr>
                    <div class="button">
                       All Programs <div class="start_arrow_button">
                       
                       <?xml version="1.0" encoding="UTF-8" standalone="no"?>
<!-- Generator: Adobe Illustrator 12.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 51448)  -->

<svg
   version="1.1"
   id="Layer_1"
   height="16"
   viewBox="0 0 186.01973 532.32868"
   overflow="visible"
   enable-background="new 0 0 460.5 531.74"
   xml:space="preserve"
   sodipodi:docname="allprogs.svg"
   inkscape:version="1.1.2 (0a00cf5339, 2022-02-04, custom)"
   xmlns:inkscape="http://www.inkscape.org/namespaces/inkscape"
   xmlns:sodipodi="http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd"
   xmlns:xlink="http://www.w3.org/1999/xlink"
   xmlns="http://www.w3.org/2000/svg"
   xmlns:svg="http://www.w3.org/2000/svg"><defs
   id="defs836"><linearGradient
     inkscape:collect="always"
     id="linearGradient1447"><stop
       style="stop-color:#ffffff;stop-opacity:1"
       offset="0"
       id="stop1443" /><stop
       style="stop-color:#000000;stop-opacity:1"
       offset="1"
       id="stop1445" /></linearGradient><linearGradient
     inkscape:collect="always"
     xlink:href="#linearGradient1447"
     id="linearGradient1449"
     x1="-17.942755"
     y1="265.24689"
     x2="97.382607"
     y2="265.24689"
     gradientUnits="userSpaceOnUse" /></defs><sodipodi:namedview
   id="namedview834"
   pagecolor="#ffffff"
   bordercolor="#666666"
   borderopacity="1.0"
   inkscape:pageshadow="2"
   inkscape:pageopacity="0.0"
   inkscape:pagecheckerboard="0"
   showgrid="false"
   inkscape:zoom="1.517659"
   inkscape:cx="178.23503"
   inkscape:cy="265.87"
   inkscape:window-width="1920"
   inkscape:window-height="1022"
   inkscape:window-x="-9"
   inkscape:window-y="-9"
   inkscape:window-maximized="1"
   inkscape:current-layer="Layer_1"
   fit-margin-top="0"
   fit-margin-left="0"
   fit-margin-right="0"
   fit-margin-bottom="0" />
<polygon
   stroke="#000000"
   points="0.5,0.866 459.5,265.87 0.5,530.874 "
   id="polygon831"
   transform="matrix(0.40395164,0,0,1.001107,0,2.5802319e-5)"
   style="stroke-width:0.99848573;stroke-miterlimit:4;stroke-dasharray:none;fill-opacity:1;fill:url(#linearGradient1449)" />
</svg>
                       
                       
                       
                       </div>
                    </div>
                </div>
                <div class="search-box">
                    <input class="w96-textbox search" placeholder="Search programs and files">
                </div>
            </div>
            <div class="p2">
                <div class="items"></div>
            </div>
        </div>
    `;

    const p2account = start.querySelector('.account');
    if(sam && sam.picture && await w96.FS.exists(sam.picture.path)) {
        let url = URL.createObjectURL(new Blob([await w96.FS.readbin(sam.picture.path)], { type: sam.picture.mime }));
        p2account.style.backgroundImage = 'url(' + url + ')';
        p2account.style.backgroundSize = 'cover';
        //URL.revokeObjectURL(url);
    }

    // Setup search box
    const searchBox = start.querySelector('.search');
    const p1items = start.querySelector(".p1>.items");
    const allProgramsBtn = start.querySelector(".all-programs>.button");

    const prgmBackHandler = async () => {
        await populateP1View(start, "quick");
        searchBox.value = "";
        allProgramsBtn.onclick = prgmAllHandler;
    };

    const prgmAllHandler = async () => {
        await populateP1View(start, "programs");
        allProgramsBtn.onclick = prgmBackHandler;
        searchBox.value = "";
    };

    allProgramsBtn.onclick = prgmAllHandler;

    searchBox.addEventListener('keydown', async(v)=>{
        try {
            if((searchBox.value.trim() == "") && (currentView !== "quick")) {
                // Revert to quick view
                await populateP1View(start, "quick");
                allProgramsBtn.textContent = "▶ All Programs";

                // All programs event handler.
                allProgramsBtn.onclick = prgmAllHandler;
            } else {
                if(searchBox.value.length < 2)
                    return;

                allProgramsBtn.textContent = "◀ Back";
                allProgramsBtn.onclick = prgmBackHandler;
                // TODO Add events to programs button to go back.

                // Show search results
                await populateP1View(start, "search");

                const diskContents = await w96.FS.walk("c:/");
                const cleanNames = diskContents.map((v)=>w96.FSUtil.fname(v));

                const lq = searchBox.value.trim().toLowerCase();

                let firstIndex = 0;

                await cleanNames.aForEach(async(n, i)=>{
                    const nLq = n.trim().toLowerCase();

                    if(nLq.includes(lq)) {
                        let el = createListItem(n, await w96.ui.Theme.getFileIconUrl(diskContents[i], "small"), ()=>{
                            w96.sys.execFile(diskContents[i]);
                        });
                        if (!firstIndex)firstIndex = i;

                        el.classList.add('small');

                        p1items.appendChild(el);
                    }
                });

                if(v.keyCode == 13){
                    fnStartClose();
                    w96.sys.execFile(diskContents[firstIndex]);
                }
            }
        } catch(e) {
            console.error(e);
        }
    });

    await populateP1View(start, "quick");

    const p2items = start.querySelector(".p2>.items");

    for(let i of startMenuItems) {
        if(i.type == "separator") {
            const s = document.createElement('div');
            s.classList.add('separator');
            p2items.appendChild(s);
        } else {
            const btn = document.createElement('button');
            btn.addEventListener('click', ()=>{
                w96.evt.shell.emit('start-close');
                i.action();
            });
            btn.innerText = i.name;
            p2items.appendChild(btn);
        }
    }

    document.querySelector('#maingfx').appendChild(start);
    searchBox.focus();
};

w96.evt.shell.on('start-opened', fnStartOpen);

let fnStartClose = ()=>{
    const s = document.querySelector('.start-menu');

    if(s) {
        while(s.firstChild)
            s.removeChild(s.firstChild);

        s.remove();
    }
};

w96.evt.shell.on('start-closed', fnStartClose);

w96.evt.ui.once('theme-unload', ()=>{
    w96.evt.shell.remove('start-opened', fnStartOpen);
    w96.evt.shell.remove('start-closed', fnStartClose);
});

//time-date thing
setTimeout(() => {
const date = new Date();

let day = date.getDate();
let month = date.getMonth() + 1;
let year = date.getFullYear();

let currentDate = `${day}/${month}/${year}`

$(".taskbar-notify").append(`<div class="notify-timedate-container" style="margin-left: 10pt;margin-top: auto;margin-bottom: auto;margin-right: 3px;"><br><span class='date-notify'>` + currentDate + `</span></div>`)
var element = $('.notify-time').detach();
$('.notify-timedate-container').prepend(element);
}, "2000");

$(".logon-app").parent().parent().css("background", "green")