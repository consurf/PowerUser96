3D File Explorer 1.0 README
---------------------------

Table Of Contents
  1. Welcome
  2. Basic Controls
  3. What Next?
  4. Credits


1. Welcome
----------

Welcome to 3D File Explorer!

As the name suggests, 3D File Explorer (3DFE) is able to explore your files in 3D!

3DFE is optimized for leanback usage, so you can use your keyboard or controller to navigate the program.

2. Basic Controls
-----------------

The basic controls for 3DFE are as follows:

ENTER - Interact with item
ARROW_LEFT - Select item to the left
ARROW_RIGHT - Select item to the right

3. What Next?
-------------
Currently, 3D File Explorer is quite bare, so we are hoping to improve it with updates. Make sure to check your package manager to get the latest updates.

4. Credits
----------
Read assets/CREDITS.txt for asset credits.

Our models are licensed under CC-BY-NC-SA.

Copyright (C) sys36.net