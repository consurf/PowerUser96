Store icon packs (aka icon themes) here.

A reboot is required to recognize them in the system.